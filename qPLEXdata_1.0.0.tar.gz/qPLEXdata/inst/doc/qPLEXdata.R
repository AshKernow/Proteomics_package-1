## ----options,echo=FALSE-----------------------------------------------
options(width=72)

## ----lbsload,message=FALSE,cache=TRUE---------------------------------
library(qPLEXdata)
library(qPLEXanalyzer)
library(dplyr)
data(human_anno)

## ----PR679,message=FALSE,cache=TRUE-----------------------------------
## load data
data(exp1_specificity)

## create MSnSet object
MSnset_data <- convertToMSnset(exp1_specificity$intensities,
                               metadata=exp1_specificity$metadata,
                               indExpData=c(6:15),indFData=c(1:5))

## Normalization
MSnset_norm <- groupScaling(MSnset_data, median)

## Summation of peptide to protein intensity
MSnset_Pnorm <- summarizeIntensities(MSnset_norm, sum, human_anno)

## Differential analysis
contrasts <- c(ER_vs_IgG = "ER - IgG")
diffstats <- computeDiffStats(data=MSnset_Pnorm, contrasts=contrasts, 
                              applyLog2Transform = TRUE)
diffexp <- getContrastResults(diffstats=diffstats, contrast=contrasts, 
                              controlGroup = NULL, ann= human_anno)
diffexp <- diffexp[which(diffexp$adj.P.Val < 0.01 & diffexp$logFC >1),]

## ----PR835,message=FALSE,cache=TRUE-----------------------------------
## load data
data(exp2_Xlink)

## create MSnSet object
MSnset_data <- convertToMSnset(exp2_Xlink$intensities,
                               metadata=exp2_Xlink$metadata,
                               indExpData=c(7:16),indFData=c(1:6))
exprs(MSnset_data) <- exprs(MSnset_data)+0.01
MSnset_data <- MSnset_data[,-5]

## Normalization
MSnset_norm <- groupScaling(MSnset_data, median, Grp="Grp")

## Summation of peptide to protein intensity
MSnset_Pnorm <- summarizeIntensities(MSnset_norm, sum, human_anno)

## Differential analysis
contrasts <- c(DSG.FA_vs_FA = "DSG.FA - FA")
diffstats <- computeDiffStats(data=MSnset_Pnorm, contrasts=contrasts, 
                              applyLog2Transform = TRUE)
diffexp <- getContrastResults(diffstats=diffstats, contrast=contrasts, 
                              controlGroup = "IgG", ann= human_anno)
diffexp <- diffexp[which(diffexp$adj.P.Val < 0.05 & abs(diffexp$logFC) > 0.5),]

## ----PR807,message=FALSE,cache=TRUE,fig.asp=0.7-----------------------
## load data
data(exp3_OHT_ESR1)

## create MSnSet object
MSnset_data1 <- convertToMSnset(exp3_OHT_ESR1$intensities_qPLEX1,
                                metadata=exp3_OHT_ESR1$metadata_qPLEX1,
                                indExpData=c(7:16),indFData=c(1:6))
pData(MSnset_data1)$Run <- 1
MSnset_data2 <- convertToMSnset(exp3_OHT_ESR1$intensities_qPLEX2,
                                metadata=exp3_OHT_ESR1$metadata_qPLEX2,
                                indExpData=c(7:16),indFData=c(1:6))
pData(MSnset_data2)$Run <- 2
MSnset_data3 <- convertToMSnset(exp3_OHT_ESR1$intensities_qPLEX3,
                                metadata=exp3_OHT_ESR1$metadata_qPLEX3,
                                indExpData=c(7:16),indFData=c(1:6))
pData(MSnset_data3)$Run <- 3

## Summation of peptide to protein intensity
MSnset_P1 <- summarizeIntensities(MSnset_data1, sum, human_anno)
MSnset_P2 <- summarizeIntensities(MSnset_data2, sum, human_anno)
MSnset_P3 <- summarizeIntensities(MSnset_data3, sum, human_anno)

## Normalization
MSnset_P1 <- rowScaling(MSnset_P1,mean)
MSnset_P2 <- rowScaling(MSnset_P2,mean)
MSnset_P3 <- rowScaling(MSnset_P3,mean)

## Combine all experiment
QRIME1_p <- cbind(fData(MSnset_P1),exprs(MSnset_P1))
QRIME2_p <- cbind(fData(MSnset_P2),exprs(MSnset_P2))
QRIME3_p <- cbind(fData(MSnset_P3),exprs(MSnset_P3))
merge12 <- merge(QRIME1_p, QRIME2_p, by = c("Protein","Gene","Description",
                                            "GeneSymbol"), all.x = FALSE)
merge123 <- merge(merge12, QRIME3_p, by = c("Protein","Gene","Description",
                                            "GeneSymbol"), all.x = FALSE)

###### Compute common unique peptides
features1 <- fData(MSnset_data1)
features1 <- as.data.frame(features1[, c("Annotated.Sequence", 
                                       "Master.Protein.Accessions")],
                           stringsAsFactors = F)
features2 <- fData(MSnset_data2)
features2 <- as.data.frame(features2[, c("Annotated.Sequence", 
                                         "Master.Protein.Accessions")],
                           stringsAsFactors = F)
features3 <- fData(MSnset_data3)
features3 <- as.data.frame(features3[, c("Annotated.Sequence", 
                                         "Master.Protein.Accessions")],
                           stringsAsFactors = F)
features <- rbind(features1,features2,features3)
features <- unique(features)
features$Annotated.Sequence <- as.character(features$Annotated.Sequence)
features$Master.Protein.Accessions <- as.character(features$Master.Protein.Accessions)
counts <- features %>% count(Master.Protein.Accessions) %>% 
  rename(Protein = Master.Protein.Accessions, Count = n)
merge123 <- merge123[,-c(16,27)]
colnames(merge123)[5] <- "Count"
ind <- match(merge123$Protein,counts$Protein)
merge123$Count <- counts$Count[ind]

##### create combine MSnSet object
metadata_comb <- rbind(pData(MSnset_data1),pData(MSnset_data2),pData(MSnset_data3))
metadata_comb$Bio.Rep <- c(rep(1,4),rep(2,4),c(1,2),rep(3,4),rep(4,4),c(3,4),
                           rep(5,4),rep(6,4),c(5,6))
MSnset_comb <- convertToMSnset(merge123,metadata=metadata_comb,
                               indExpData=c(6:ncol(merge123)),indFData=c(1:5))
rownames(MSnset_comb) <- merge123$Protein

### create separate MSnSet for IgG comparision
pheno <- pData(MSnset_comb)
pheno$Label <- c(rep(c(rep("Exp",8),rep("IgG",2)),3))
pheno$Label <- factor(pheno$Label)
MSnset_IgG <- MSnset_comb
pData(MSnset_IgG) <- pheno

### Differential analysis to find ER specific interactors
contrasts <- c(
  Exp_vs_IgG = "Exp - IgG"
)
diffstats <- computeDiffStats(data=MSnset_IgG, contrasts=contrasts, 
                              applyLog2Transform = FALSE)
results <- getContrastResults(diffstats=diffstats, contrast=contrasts, 
                              controlGroup = NULL, ann= human_anno,
                              applyLog2Transform = FALSE)

### create subset of protein filtering non-specific IgG
ind <- which(results$adj.P.Val < 0.01 & results$logFC > 1)
diff_IgG <- results[ind,]
ind <- match(diff_IgG$Protein,fData(MSnset_comb)$Protein)
MSnset_subset <- MSnset_comb[ind]
IgG_ind <- which(pData(MSnset_subset)$Label == "IgG")

### perform regression analysis on dataset
MSnset_reg <- regressIntensity(MSnset_subset,controlInd=IgG_ind,ProteinId="P03372")

### Differential analysis
contrasts <- c(
  tam.2h_vs_vehicle = "tam.2h - vehicle",
  tam.6h_vs_vehicle = "tam.6h - vehicle",
  tam.24h_vs_vehicle = "tam.24h - vehicle"
)

suppressWarnings(diffstats <- computeDiffStats(data=MSnset_reg, contrasts=contrasts, 
                              applyLog2Transform = FALSE))

diffexp1 <- getContrastResults(diffstats=diffstats, contrast=contrasts[1], 
                              controlGroup = NULL, ann= human_anno,
                              applyLog2Transform = FALSE)
diffexp1 <- diffexp1[which(diffexp1$adj.P.Val < 0.05 & abs(diffexp1$logFC) > 0.5),]
diffexp2 <- getContrastResults(diffstats=diffstats, contrast=contrasts[2], 
                              controlGroup = NULL, ann= human_anno,
                              applyLog2Transform = FALSE)
diffexp2 <- diffexp2[which(diffexp2$adj.P.Val < 0.05 & abs(diffexp2$logFC) > 0.5),]
diffexp3 <- getContrastResults(diffstats=diffstats, contrast=contrasts[3], 
                              controlGroup = NULL, ann= human_anno,
                              applyLog2Transform = FALSE)
diffexp3 <- diffexp3[which(diffexp3$adj.P.Val < 0.05 & abs(diffexp3$logFC) > 0.5),]

## ----PR809,message=FALSE,cache=TRUE-----------------------------------
## load data
data(exp4_OHT_FP)

## create MSnSet object
MSnset_data1 <- convertToMSnset(exp4_OHT_FP$FP_1,
                                metadata=exp4_OHT_FP$metadata_FP1,
                                indExpData=c(7:14),indFData=c(1:6))
pData(MSnset_data1)$Run <- 1
MSnset_data2 <- convertToMSnset(exp4_OHT_FP$FP_2,
                                metadata=exp4_OHT_FP$metadata_FP2,
                                indExpData=c(7:14),indFData=c(1:6))
pData(MSnset_data2)$Run <- 2

## Summation of peptide to protein intensity
MSnset_P1 <- summarizeIntensities(MSnset_data1, sum, human_anno)
MSnset_P2 <- summarizeIntensities(MSnset_data2, sum, human_anno)

## Combine all experiment
FP1_p <- cbind(fData(MSnset_P1),exprs(MSnset_P1))
FP2_p <- cbind(fData(MSnset_P2),exprs(MSnset_P2))
merge12 <- merge(FP1_p, FP2_p, by = c("Protein","Gene","Description",
                                      "GeneSymbol"),all.x = FALSE)
merge12 <- merge12[,-c(14)]
colnames(merge12)[5] <- "Count"

### Computing common unique peptides 
features1 <- fData(MSnset_data1)
features1 <- as.data.frame(features1[, c("Annotated.Sequence", 
                                       "Master.Protein.Accessions")],
                           stringsAsFactors = F)
features2 <- fData(MSnset_data2)
features2 <- as.data.frame(features2[, c("Annotated.Sequence", 
                                         "Master.Protein.Accessions")],
                           stringsAsFactors = F)
features <- rbind(features1,features2)
features <- unique(features)
features$Annotated.Sequence <- as.character(features$Annotated.Sequence)
features$Master.Protein.Accessions <- as.character(features$Master.Protein.Accessions)
counts <- features %>% count(Master.Protein.Accessions) %>% 
  rename(Protein = Master.Protein.Accessions, Count = n)
ind <- match(merge12$Protein,counts$Protein)
merge12$Count <- counts$Count[ind]

##### create combine MSnSet object
metadata_comb <- rbind(pData(MSnset_data1),pData(MSnset_data2))
MSnset_comb <- convertToMSnset(merge12,metadata=metadata_comb,
                               indExpData=c(6:ncol(merge12)),indFData=c(1:5))

## Normalization
MSnset_Pnorm <- normalizeScaling(MSnset_comb, median)

## Differential analysis
contrasts <- c(
  tam.2h_vs_vehicle = "tam.2h - vehicle",
  tam.6h_vs_vehicle = "tam.6h - vehicle",
  tam.24h_vs_vehicle = "tam.24h - vehicle"
)
batchEffect <- c("Run", "Bio.Rep")

diffstats <- computeDiffStats(data=MSnset_Pnorm, contrasts=contrasts, 
                              applyLog2Transform = TRUE, batchEffect=batchEffect)

diffexp1 <- getContrastResults(diffstats=diffstats, contrast=contrasts[1], 
                              controlGroup = NULL, ann= human_anno)
diffexp1 <- diffexp1[which(diffexp1$adj.P.Val < 0.05 & abs(diffexp1$logFC) > 0.5),]
diffexp2 <- getContrastResults(diffstats=diffstats, contrast=contrasts[2], 
                              controlGroup = NULL, ann= human_anno)
diffexp2 <- diffexp2[which(diffexp2$adj.P.Val < 0.05 & abs(diffexp2$logFC) > 0.5),]
diffexp3 <- getContrastResults(diffstats=diffstats, contrast=contrasts[3], 
                              controlGroup = NULL, ann= human_anno)
diffexp3 <- diffexp3[which(diffexp3$adj.P.Val < 0.05 & abs(diffexp3$logFC) > 0.5),]

## ----PR842,message=FALSE,cache=TRUE-----------------------------------
## load data
data(exp5_PDX)

## create MSnSet object
MSnset_data <- convertToMSnset(exp5_PDX$intensities, metadata=exp5_PDX$metadata,
                               indExpData=c(7:16), indFData=c(1:6))

## Exclude outlier and techical replicate samples
MSnset_data <- MSnset_data[,-c(2,7:10)]

## Normalization
MSnset_norm <- groupScaling(MSnset_data, median, Grp="Grp")

## Summation of peptide to protein intensity
MSnset_Pnorm <- summarizeIntensities(MSnset_norm, sum, human_anno)

## Differential analysis
contrasts <- c(PDX_vs_IgG = "PDX - IgG")

diffstats <- computeDiffStats(data=MSnset_Pnorm, contrasts=contrasts)
diffexp <- getContrastResults(diffstats=diffstats, contrast=contrasts, ann= human_anno)
diffexp <- diffexp[which(diffexp$adj.P.Val < 0.01 & diffexp$logFC > 1),]

## ----info,echo=TRUE---------------------------------------------------
sessionInfo()

